# NOTE sapjco3 Artifact id must contains com.sap.conn.jco. to avoid jar name verification error

mvn install:install-file -Dfile=sapjco3.jar -DgroupId=com.sap -DartifactId=com.sap.conn.jco.sapjco3 -Dversion=3.0.19 -Dpackaging=jar
mvn install:install-file -Dfile=sapidoc3.jar -DgroupId=com.sap -DartifactId=com.sap.conn.idoc.sapidoc3 -Dversion=3.0.19 -Dpackaging=jar

# Native library MacOS 32 bits, version 3.0.19:
mvn install:install-file -DgroupId=com.sap -DartifactId=com.sap.conn.jco.sapjco3-native -Dversion=3.0.19 -Dclassifier=darwinintel -Dpackaging=jnilib -Dfile=./native/osx32/libsapjco3.jnilib

# Native library Linux 32 bits, version 3.0.19:
mvn install:install-file -DgroupId=com.sap -DartifactId=com.sap.conn.jco.sapjco3-native -Dversion=3.0.19 -Dclassifier=linuxintel -Dpackaging=so -Dfile=./native/linux32/libsapjco3.so

# Native library Windows/dos 32 bits, version 3.0.19:
mvn install:install-file -DgroupId=com.sap -DartifactId=com.sap.conn.jco.sapjco3-native -Dversion=3.0.19 -Dclassifier=ntintel -Dpackaging=dll -Dfile=./native/win32/sapjco3.dll


# Native library MacOS 64 bits, version 3.0.19:
mvn install:install-file -DgroupId=com.sap -DartifactId=com.sap.conn.jco.sapjco3-native -Dversion=3.0.19 -Dclassifier=darwinintel64 -Dpackaging=jnilib -Dfile=./native/osx64/libsapjco3.jnilib

# Native library Linux x86 64 bits, version 3.0.19:
mvn install:install-file -DgroupId=com.sap -DartifactId=com.sap.conn.jco.sapjco3-native -Dversion=3.0.19 -Dclassifier=linuxx86_64 -Dpackaging=so -Dfile=./native/linux64/libsapjco3.so

# Native library Windows/dos AMD 64 bits, version 3.0.19:
mvn install:install-file -DgroupId=com.sap -DartifactId=com.sap.conn.jco.sapjco3-native -Dversion=3.0.19 -Dclassifier=ntamd64 -Dpackaging=dll -Dfile=./native/win64/sapjco3.dll
