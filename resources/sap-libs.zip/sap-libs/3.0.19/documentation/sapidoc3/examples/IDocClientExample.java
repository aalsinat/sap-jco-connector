package com.sap.conn.idoc.examples;

import com.sap.conn.jco.*;
import com.sap.conn.idoc.jco.*;
import com.sap.conn.idoc.*;
import java.io.*;

public class IDocClientExample {

	public static void main(String[] args) {
		
		try
        {
			String iDocXML = null;
			FileReader fileReader;

			try
			{
				fileReader = new FileReader("MyIDocDocumentAsXML.xml");
				BufferedReader br = new BufferedReader(fileReader);
				StringBuffer sb = new StringBuffer();
				String line;
				while ((line = br.readLine()) != null)
				{
					sb.append(line);
				}
				iDocXML = sb.toString();
				
				
				br.close();
				fileReader.close();
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
			
			// see provided configuration file BCE.jcoDestination
        	JCoDestination destination=JCoDestinationManager.getDestination("BCE"); 
        	IDocRepository iDocRepository = JCoIDoc.getIDocRepository(destination);
        	String tid = destination.createTID();
        	IDocFactory iDocFactory = JCoIDoc.getIDocFactory();
        	
        	// a) create new idoc
        	IDocDocument doc = iDocFactory.createIDocDocument(iDocRepository, "MATMAS02");
        	IDocSegment segment = doc.getRootSegment();
        	segment = segment.addChild("E1MARAM");
        	// and so on. See Idoc Specification .....
        	JCoIDoc.send(doc, IDocFactory.IDOC_VERSION_DEFAULT, destination, tid);
        	
        	
        	// b) use existent xml file
        	IDocXMLProcessor processor=iDocFactory.getIDocXMLProcessor();
            IDocDocumentList iDocList=processor.parse(iDocRepository, iDocXML);
            JCoIDoc.send(iDocList, IDocFactory.IDOC_VERSION_DEFAULT, destination, tid);
            destination.confirmTID(tid);
            
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }
        System.out.print("program end");
	}
}
